import { OasisPressable as Pressable, OasisTextInput as TextInput, OasisSurface } from '@/components/oasis/OasisPrimitives';
import { OASIS } from '@/lib/oasis';
import { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Modal, View, Text, ScrollView, StyleSheet, Platform } from 'react-native';
import {
  SAUDI_REGIONS,
  buildSaudiLocations,
  normalizeSaudiLocationName,
  isKnownSaudiCity,
  isInsideSaudiArabia,
  Region,
  City,
  District,
  CustomLocation,
  LocationOverride,
} from '@/lib/saudiLocations';
import { supabase } from '@/lib/supabase';
import { getLockedCity } from '@/lib/locationSync';
import {
  MapPin,
  X,
  ChevronLeft,
  ChevronRight,
  Search,
  Check,
  Compass,
  Building2,
  Sparkles,
} from 'lucide-react-native';
import { C } from '@/lib/ui';
import { resolveShortNationalAddress, NationalAddressResolution } from '@/lib/nationalAddress';
import { getCurrentDeviceLocation, reverseGeocodeDeviceLocation } from '@/lib/deviceLocation';
import ActionSheet from '@/components/ActionSheet';

interface Props {
  visible: boolean;
  onClose: () => void;
  selectedCity: string;
  selectedDistrict: string;
  /** GPS-verified city. When set, the city cannot be changed from this modal. */
  lockedCity?: { region: string; city: string } | null;
  onSelect: (region: string, city: string, district: string) => void;
}

export default function LocationSelectorModal({
  visible,
  onClose,
  selectedCity,
  selectedDistrict,
  lockedCity,
  onSelect,
}: Props) {
  // Step 1: Region -> Step 2: City -> Step 3: District
  const [step, setStep] = useState<'region' | 'city' | 'district'>('region');
  const [selectedReg, setSelectedReg] = useState<Region | null>(null);
  const [selectedCit, setSelectedCit] = useState<City | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [locations, setLocations] = useState<Region[]>(SAUDI_REGIONS);
  const [visibleCount, setVisibleCount] = useState(100);
  const [locating, setLocating] = useState(false);
  const [ownLocked, setOwnLocked] = useState<{ region: string; city: string } | null>(null);
  const [autoLocateAttempted, setAutoLocateAttempted] = useState(false);

  // Self-load the GPS lock so every screen that opens this modal respects it,
  // even if the caller does not pass `lockedCity` explicitly.
  useEffect(() => {
    if (!visible || autoLocateAttempted) return;
    let active = true;
    getLockedCity().then(lock => {
      if (!active) return;
      setOwnLocked(lock ? { region: lock.region, city: lock.city } : null);

      const hasSavedCity = Boolean(
        selectedCity &&
        !['كل المدن', 'كل المملكة', 'الكل', 'جميع المدن'].includes(selectedCity.trim()) &&
        isKnownSaudiCity(selectedCity)
      );

      // First-time setup: detect the real city and neighborhood automatically.
      // Manual browsing remains only as a fallback when GPS/geocoding is unavailable.
      if (!lock && !hasSavedCity) {
        setAutoLocateAttempted(true);
        void handleUseCurrentLocation();
      }
    }).catch(() => {
      if (!active) return;
      if (!selectedCity || ['كل المدن', 'كل المملكة', 'الكل', 'جميع المدن'].includes(selectedCity.trim())) {
        setAutoLocateAttempted(true);
        void handleUseCurrentLocation();
      }
    });
    return () => { active = false; };
  }, [visible, selectedCity, autoLocateAttempted]);

  // Once a city is selected, keep the selector scoped to that city.
  // Users can choose only their district or the whole city.
  const activeLock = lockedCity ?? ownLocked ?? (
    selectedCity && selectedCity !== 'كل المدن' && selectedCity !== 'كل المملكة' && isKnownSaudiCity(selectedCity)
      ? { region: '', city: selectedCity }
      : null
  );

  useEffect(() => {
    if (!visible) return;
    let active = true;
    Promise.all([
      supabase.from('saudi_custom_locations').select('id,region_name,city_name,district_name,latitude,longitude').limit(5000),
      supabase.from('saudi_location_overrides').select('source_id,new_name,is_deleted'),
    ]).then(([customResult, overrideResult]) => {
      if (!active) return;
      const overrides = (overrideResult.data || []) as LocationOverride[];
      setLocations(buildSaudiLocations((customResult.data || []) as CustomLocation[], overrides));
    });
    return () => { active = false; };
  }, [visible]);

  useEffect(() => { setVisibleCount(100); }, [step, searchQuery]);

  // When a GPS-verified city exists, the user may only pick a district inside it.
  const lockActive = Boolean(activeLock && activeLock.city && activeLock.city !== 'كل المدن' && isKnownSaudiCity(activeLock.city));
  const lockedResolved = useMemo(() => {
    if (!lockActive || !activeLock) return null;
    const target = normalizeSaudiLocationName(activeLock.city);
    for (const reg of locations) {
      const cit = reg.cities.find(c => normalizeSaudiLocationName(c.name) === target);
      if (cit) return { region: reg, city: cit };
    }
    return null;
  }, [lockActive, activeLock, locations]);

  useEffect(() => {
    if (!visible || !lockedResolved) return;
    setSelectedReg(lockedResolved.region);
    setSelectedCit(lockedResolved.city);
    setStep('district');
    setSearchQuery('');
  }, [visible, lockedResolved]);

  // National Address Short Code state
  const [shortCodeInput, setShortCodeInput] = useState('');
  const [resolvedAddress, setResolvedAddress] = useState<NationalAddressResolution | null>(null);

  function handleShortCodeChange(text: string) {
    setShortCodeInput(text);
    const resolved = resolveShortNationalAddress(text);
    setResolvedAddress(resolved);
  }

  function handleApplyResolvedAddress() {
    if (!resolvedAddress) return;
    if (lockActive && activeLock && normalizeSaudiLocationName(resolvedAddress.city) !== normalizeSaudiLocationName(activeLock.city)) {
      Alert.alert('المدينة غير متاحة', `نطاقك الحالي هو ${activeLock.city}. يمكنك اختيار حي داخله أو المدينة كاملة فقط.`);
      return;
    }
    onSelect(resolvedAddress.region, resolvedAddress.city, resolvedAddress.district);
    resetAndClose();
  }

  function resetAndClose() {
    setStep('region');
    setSelectedReg(null);
    setSelectedCit(null);
    setSearchQuery('');
    setShortCodeInput('');
    setResolvedAddress(null);
    onClose();
  }

  async function handleUseCurrentLocation() {
    if (locating) return;
    setLocating(true);
    try {
      const location = await getCurrentDeviceLocation();
      if (!location) {
        Alert.alert('تعذّر تحديد الموقع', 'اسمح للمتصفح أو التطبيق باستخدام موقعك ثم حاول مرة أخرى.');
        return;
      }
      if (!isInsideSaudiArabia(location.latitude, location.longitude)) {
        Alert.alert(
          'الموقع خارج المملكة 🇸🇦',
          'موقع جهازك الحالي خارج المملكة العربية السعودية. يرجى اختيار منطقتك ومدينتك يدوياً من القائمة.'
        );
        return;
      }
      const place = await reverseGeocodeDeviceLocation(location);
      if (place?.isOutsideKSA) {
        Alert.alert(
          'الموقع خارج المملكة 🇸🇦',
          'موقع جهازك الحالي خارج المملكة العربية السعودية. يرجى اختيار منطقتك ومدينتك يدوياً من القائمة.'
        );
        return;
      }
      const region = place?.region?.trim() || '';
      const city = place?.city?.trim() || '';
      const district = place?.district?.trim() || '';
      if (!region || !city || !district || !isKnownSaudiCity(city)) {
        Alert.alert('الموقع غير مكتمل', 'لم نتمكن من مطابقة المنطقة والمدينة والحي بدقة مع مدن المملكة. اخترها يدوياً من القائمة.');
        return;
      }
      onSelect(region, city, district);
      resetAndClose();
    } catch (error: any) {
      Alert.alert('تعذّر تحديد الموقع', error?.message || 'اختر المنطقة والمدينة والحي يدوياً.');
    } finally {
      setLocating(false);
    }
  }

  function handleChooseRegion(reg: Region) {
    if (lockActive && activeLock) {
      Alert.alert('خارج نطاقك', `لا يمكنك الوصول إلى مناطق أو مدن أخرى. نطاقك الحالي هو ${activeLock.city}.`);
      return;
    }
    setSelectedReg(reg);
    setStep('city');
    setSearchQuery('');
  }

  function handleChooseCity(cit: City) {
    if (lockActive && activeLock && normalizeSaudiLocationName(cit.name) !== normalizeSaudiLocationName(activeLock.city)) {
      Alert.alert('خارج نطاقك', `لا يمكنك الانتقال إلى مدينة أخرى. اختر حيّك داخل ${activeLock.city} أو المدينة كاملة.`);
      return;
    }
    setSelectedCit(cit);
    setStep('district');
    setSearchQuery('');
  }

  function handleChooseAllCityDistricts() {
    if (!selectedReg || !selectedCit) return;
    onSelect(selectedReg.name, selectedCit.name, 'كل الأحياء');
    resetAndClose();
  }

  function handleChooseDistrict(dist: District) {
    if (!selectedReg || !selectedCit) return;
    onSelect(selectedReg.name, selectedCit.name, dist.name);
    resetAndClose();
  }

  // Filtered lists
  const queryKey = normalizeSaudiLocationName(searchQuery);
  const filteredRegions = locations.filter(r => normalizeSaudiLocationName(r.name).includes(queryKey));

  const filteredCities = (selectedReg?.cities || []).filter(c =>
    normalizeSaudiLocationName(c.name).includes(queryKey)
  );

  const filteredDistricts = (selectedCit?.districts || []).filter(d =>
    normalizeSaudiLocationName(d.name).includes(queryKey)
  );

  // If the user already has a district, expose only that district plus the whole-city option.
  // District browsing is available only during first-time setup when no district is saved yet.
  const hasSavedDistrict = Boolean(
    selectedDistrict &&
    !['كل الأحياء', 'كل أحياء المدينة', 'جميع الأحياء', 'الكل'].includes(selectedDistrict.trim())
  );
  const districtOptions = lockActive && hasSavedDistrict
    ? filteredDistricts.filter(d => normalizeSaudiLocationName(d.name) === normalizeSaudiLocationName(selectedDistrict))
    : filteredDistricts;

  return (
    <ActionSheet
      visible={visible}
      onClose={resetAndClose}
      height="85%"
    >
      <View style={{ flex: 1 }}>
          {/* Header */}
          <View style={styles.header}>
            <Pressable oasisKind="icon" onPress={resetAndClose} style={styles.closeBtn}>
              <X size={22} color={OASIS.colors.muted} />
            </Pressable>

            <View style={{ flex: 1, alignItems: 'center' }}>
              <Text style={styles.headerTitle}>
                {step === 'region' && 'اختر المنطقة 🇸🇦'}
                {step === 'city' && `مدن ${selectedReg?.name}`}
                {step === 'district' && `أحياء ${selectedCit?.name}`}
              </Text>
              <Text style={styles.headerSub}>
                {step === 'region' && 'سنحدد مدينتك وحيّك تلقائيًا عند السماح بالموقع'}
                {step === 'city' && 'اختر مدينتك الحالية'}
                {step === 'district' && 'تم تحديد موقعك؛ الأحياء المعروضة تخص هذه المدينة فقط'}
              </Text>
            </View>

            {step !== 'region' && !lockActive ? (
              <Pressable oasisKind="icon"
                onPress={() => setStep(step === 'district' ? 'city' : 'region')}
                style={styles.backBtn}
              >
                <ChevronRight size={22} color={OASIS.colors.primary} />
              </Pressable>
            ) : (
              <View style={{ width: 40 }} />
            )}
          </View>

          {lockActive && activeLock && (
            <View style={styles.lockBanner}>
              <MapPin size={16} color="#b45309" />
              <Text style={styles.lockBannerText}>
                نطاقك محدد في {activeLock.city}. اختر حيّك فقط أو المدينة كاملة؛ بقية المدن والمناطق غير متاحة.
              </Text>
            </View>
          )}

          {/* Search Bar */}
          <View style={styles.searchBar}>
            <Search size={18} color="#94a3b8" />
            <TextInput
              style={styles.searchInput}
              placeholder={
                step === 'region'
                  ? 'ابحث عن منطقة...'
                  : step === 'city'
                  ? 'ابحث عن مدينة...'
                  : 'ابحث عن حي...'
              }
              placeholderTextColor="#94a3b8"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>

          {/* List Content */}
          <ScrollView
            style={styles.scrollArea}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
          >
            {/* Step 1: Regions */}
            {step === 'region' && (
              <>
                <Pressable oasisKind="action"
                  style={styles.currentLocationButton}
                  onPress={handleUseCurrentLocation}
                  disabled={locating}
                  accessibilityRole="button"
                  accessibilityLabel="تحديد موقعي تلقائياً"
                >
                  {locating ? <ActivityIndicator size="small" color={OASIS.colors.surface} /> : <Compass size={18} color={OASIS.colors.surface} />}
                  <Text style={styles.currentLocationButtonText}>
                    {locating ? 'جارٍ تحديد موقعك…' : 'تحديد موقعي تلقائياً'}
                  </Text>
                </Pressable>

                {/* National Address Short Code Entry Box */}
                <OasisSurface oasisSurface="card" style={styles.nationalAddressCard}>
                  <View style={styles.naHeaderRow}>
                    <Sparkles size={16} color={OASIS.colors.primary} />
                    <Text style={styles.naHeaderTitle}>تحديد سريع برمز العنوان الوطني</Text>
                  </View>
                  <Text style={styles.naDesc}>
                    اكتب الرمز المختصر لعنوانك (مثال: RRRD2929) للتحديد الدقيق فوراً
                  </Text>
                  <View style={styles.naInputRow}>
                    <Building2 size={18} color={OASIS.colors.primary} />
                    <TextInput
                      style={styles.naInput}
                      placeholder="أدخل الرمز مثل RRRD2929..."
                      placeholderTextColor="#94a3b8"
                      value={shortCodeInput}
                      onChangeText={handleShortCodeChange}
                      autoCapitalize="characters"
                      maxLength={10}
                    />
                  </View>

                  {resolvedAddress && (
                    <View style={styles.resolvedBox}>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.resolvedLabel}>تم التعرف على العنوان:</Text>
                        <Text style={styles.resolvedValue}>
                          {resolvedAddress.region} · {resolvedAddress.city} · حي {resolvedAddress.district}
                        </Text>
                      </View>
                      <Pressable oasisKind="action"
                        style={styles.applyResolvedBtn}
                        onPress={handleApplyResolvedAddress}
                      >
                        <Text style={styles.applyResolvedText}>تأكيد واختيار</Text>
                      </Pressable>
                    </View>
                  )}
                </OasisSurface>

                <View style={styles.divider} />

                {filteredRegions.map(reg => (
                  <Pressable oasisKind="card"
                    key={reg.id}
                    style={styles.itemCard}
                    onPress={() => handleChooseRegion(reg)}
                  >
                    <ChevronLeft size={20} color="#94a3b8" />
                    <View style={{ flex: 1 }}>
                      <Text style={styles.itemTitle}>{reg.name}</Text>
                      <Text style={styles.itemDesc}>{reg.cities.length} مدن ومحافظات رئيسية</Text>
                    </View>
                    <View style={styles.itemIconWrap}>
                      <MapPin size={18} color={OASIS.colors.primary} />
                    </View>
                  </Pressable>
                ))}
              </>
            )}

            {/* Step 2: Cities */}
            {step === 'city' && (
              <>
                {filteredCities.slice(0, visibleCount).map(cit => {
                  const isCitySelected = selectedCity === cit.name;
                  return (
                    <Pressable oasisKind="card"
                      key={cit.id}
                      style={[styles.itemCard, isCitySelected && styles.itemCardSelected]}
                      onPress={() => handleChooseCity(cit)}
                    >
                      <ChevronLeft size={20} color="#94a3b8" />
                      <View style={{ flex: 1 }}>
                        <Text style={styles.itemTitle}>{cit.name}</Text>
                        <Text style={styles.itemDesc}>{cit.districts.length} حيًا من بيانات المدينة</Text>
                      </View>
                      <View style={styles.itemIconWrap}>
                        <MapPin size={18} color={OASIS.colors.primary} />
                      </View>
                    </Pressable>
                  );
                })}
                {filteredCities.length > visibleCount && <Pressable style={styles.loadMore} onPress={() => setVisibleCount(count => count + 100)}><Text style={styles.loadMoreText}>عرض ١٠٠ مدينة إضافية · المتبقي {filteredCities.length - visibleCount}</Text></Pressable>}
              </>
            )}

            {/* Step 3: Districts */}
            {step === 'district' && (
              <>
                {/* Option for All Districts in this City */}
                <Pressable oasisKind="card"
                  style={[
                    styles.itemCard,
                    selectedCity === selectedCit?.name && selectedDistrict === 'كل الأحياء' && styles.itemCardSelected,
                  ]}
                  onPress={handleChooseAllCityDistricts}
                >
                  <View style={styles.itemRadio}>
                    {selectedCity === selectedCit?.name && selectedDistrict === 'كل الأحياء' && (
                      <Check size={16} color={OASIS.colors.primary} />
                    )}
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.itemTitle}>كل أحياء {selectedCit?.name}</Text>
                    <Text style={styles.itemDesc}>تصفح كل ما ينشره جيران {selectedCit?.name}</Text>
                  </View>
                </Pressable>

                <View style={styles.divider} />

                {districtOptions.slice(0, visibleCount).map(dist => {
                  const isSelected = selectedCity === selectedCit?.name && selectedDistrict === dist.name;
                  return (
                    <Pressable oasisKind="card"
                      key={dist.id}
                      style={[styles.itemCard, isSelected && styles.itemCardSelected]}
                      onPress={() => handleChooseDistrict(dist)}
                    >
                      <View style={styles.itemRadio}>
                        {isSelected && <Check size={16} color={OASIS.colors.primary} />}
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.itemTitle}>{dist.name}</Text>
                      </View>
                      <View style={styles.itemIconWrap}>
                        <MapPin size={18} color={OASIS.colors.primary} />
                      </View>
                    </Pressable>
                  );
                })}
                {districtOptions.length > visibleCount && <Pressable style={styles.loadMore} onPress={() => setVisibleCount(count => count + 100)}><Text style={styles.loadMoreText}>عرض أحياء إضافية · المتبقي {districtOptions.length - visibleCount}</Text></Pressable>}
              </>
            )}
          </ScrollView>
      </View>
    </ActionSheet>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.65)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: OASIS.colors.surface,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    maxHeight: '85%',
    minHeight: '60%',
    paddingBottom: Platform.OS === 'ios' ? 40 : 20,
  },
  header: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 14,
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  closeBtn: {
    width: 40,
    height: 40,
    borderRadius: 14,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 14,
    backgroundColor: OASIS.colors.soft,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: OASIS.colors.ink,
  },
  headerSub: {
    fontSize: 12,
    color: OASIS.colors.muted,
    marginTop: 2,
  },
  searchBar: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: OASIS.colors.background,
    marginHorizontal: 20,
    marginVertical: 12,
    paddingHorizontal: 14,
    height: 46,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: OASIS.colors.line,
    gap: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: OASIS.colors.ink,
    textAlign: 'right',
  },
  scrollArea: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 16,
    gap: 10,
  },
  divider: {
    height: 1,
    backgroundColor: '#f1f5f9',
    marginVertical: 6,
  },
  lockBanner: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
    marginHorizontal: 20,
    marginTop: 12,
    backgroundColor: OASIS.colors.warningSoft,
    borderWidth: 1,
    borderColor: '#fde68a',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 9,
  },
  lockBannerText: {
    flex: 1,
    fontSize: 12,
    lineHeight: 18,
    color: '#b45309',
    fontWeight: '600',
    textAlign: 'right',
  },
  loadMore: { alignItems: 'center', padding: 14, borderRadius: 14, backgroundColor: OASIS.colors.soft },
  loadMoreText: { color: OASIS.colors.primary, fontSize: 13, fontWeight: '600' },
  itemCard: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    padding: 14,
    borderRadius: 16,
    backgroundColor: OASIS.colors.background,
    borderWidth: 1.5,
    borderColor: '#f1f5f9',
    gap: 12,
  },
  itemCardSelected: {
    borderColor: OASIS.colors.primary,
    backgroundColor: OASIS.colors.soft,
  },
  itemIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: OASIS.colors.soft,
    justifyContent: 'center',
    alignItems: 'center',
  },
  itemRadio: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#cbd5e1',
    justifyContent: 'center',
    alignItems: 'center',
  },
  itemTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: OASIS.colors.ink,
    textAlign: 'right',
  },
  itemDesc: {
    fontSize: 12,
    color: OASIS.colors.muted,
    textAlign: 'right',
    marginTop: 2,
  },
  currentLocationButton: {
    minHeight: 46,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginBottom: 8,
    borderRadius: 14,
    backgroundColor: OASIS.colors.primary,
  },
  currentLocationButtonText: { color: OASIS.colors.surface, fontSize: 13, fontWeight: '700' },
  nationalAddressCard: {
    backgroundColor: OASIS.colors.soft,
    borderWidth: 1.5,
    borderColor: '#a7f3d0',
    borderRadius: 16,
    padding: 14,
    marginBottom: 6,
  },
  naHeaderRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  naHeaderTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: OASIS.colors.primary,
    textAlign: 'right',
  },
  naDesc: {
    fontSize: 12,
    color: OASIS.colors.deep,
    textAlign: 'right',
    marginBottom: 10,
  },
  naInputRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: OASIS.colors.surface,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#a7f3d0',
    paddingHorizontal: 12,
    height: 44,
    gap: 8,
  },
  naInput: {
    flex: 1,
    fontSize: 14,
    fontWeight: '700',
    color: OASIS.colors.primary,
    textAlign: 'right',
  },
  resolvedBox: {
    marginTop: 10,
    backgroundColor: OASIS.colors.surface,
    borderRadius: 12,
    padding: 10,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#a7f3d0',
    gap: 10,
  },
  resolvedLabel: {
    fontSize: 11,
    color: OASIS.colors.muted,
    textAlign: 'right',
  },
  resolvedValue: {
    fontSize: 13,
    fontWeight: '600',
    color: OASIS.colors.ink,
    textAlign: 'right',
    marginTop: 2,
  },
  applyResolvedBtn: {
    backgroundColor: OASIS.colors.primary,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
  },
  applyResolvedText: {
    color: OASIS.colors.surface,
    fontSize: 12,
    fontWeight: '600',
  },
});
